import 'package:get_storage/get_storage.dart';

class AppStorage {
  static const String DARK_MODE = "darkMode";
  static const USER_ID = "USERID";
  static const USER_DATA = "USER_PROFILE";
  static final box = GetStorage();
}
