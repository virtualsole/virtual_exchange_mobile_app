import 'package:flutter/cupertino.dart';

class HomePageProvider extends ChangeNotifier {
  PageController homePageCtrl = PageController();
}
