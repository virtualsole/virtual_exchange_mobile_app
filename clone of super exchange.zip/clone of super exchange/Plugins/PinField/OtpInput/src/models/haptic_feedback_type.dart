part of pin_code_fields;

enum HapticFeedbackTypes {
  heavy,
  light,
  medium,
  selection,
  vibrate,
}
