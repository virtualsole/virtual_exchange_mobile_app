part of pin_code_fields;

enum AnimationType { scale, slide, fade, none }
