class DataTab {
  String? title;
  bool? isSelected;

  DataTab({this.title, this.isSelected});
}
