import 'package:flutter/material.dart';
import 'package:virtual_exchange/string_and_consts.dart';

Container divider = Container(color: AppColors.dividerColor, height: 1);
